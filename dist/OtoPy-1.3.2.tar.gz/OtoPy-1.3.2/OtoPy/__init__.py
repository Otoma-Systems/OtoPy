"""
OtoPy.

A Otoma Systems developed Lib, Containing useful Tools.
"""

__version__ = "1.3.2"
__author__ = 'Otoma Systems'
__name__="OtoPy"