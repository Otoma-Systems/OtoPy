"""
OtoPy.

Custom Lib Containing usefool Tools ins class construction.
"""

__version__ = "0.1.1"
__author__ = 'Otoma Systems'