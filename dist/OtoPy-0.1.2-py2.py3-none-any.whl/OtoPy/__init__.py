"""
OtoPy.

Custom Lib Containing usefool Tools ins class construction.
"""

__version__ = "0.1.2"
__author__ = 'Otoma Systems'